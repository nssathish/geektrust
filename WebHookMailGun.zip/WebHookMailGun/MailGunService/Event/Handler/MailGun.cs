﻿namespace MailGunService.Event.Handler
{
    public class MailGun
    {
        enum EventType
        {
            OPENED,
            CLICKED
        }

        public void SendNotification(MessageProcessingHandler message)
        {
            //message.
        }
    }
}
