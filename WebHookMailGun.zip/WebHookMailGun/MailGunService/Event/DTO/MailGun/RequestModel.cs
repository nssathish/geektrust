﻿namespace MailGunService.Event.DTO.MailGun
{
    public class RequestModel
    {
        public string Provider { get; set; } = string.Empty;
        public string timestamp { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
    }
}
