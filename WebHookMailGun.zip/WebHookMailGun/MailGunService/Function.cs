using Amazon.Lambda.Core;
using MailGunService.Event.DTO.MailGun;
using MailGunService.Notification;
using MailGunService.Storage;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace MailGunService;

public class Function
{
    

    /// <summary>
    /// A simple function that takes a string and does a ToUpper
    /// </summary>
    /// <param name="input"></param>
    /// <param name="context"></param>
    /// <returns></returns>
    public async Task FunctionHandler(object input, ILambdaContext context)
    {
        var inputString = input != null ? input.ToString() : string.Empty;

        var request = JObject.Parse(inputString);
        var bytes = Encoding.UTF8.GetBytes(inputString ?? "");
        var requestBody = JsonConvert.DeserializeObject<RequestModel>(request["body"].ToString());

        //Identify the provider
        if (!requestBody.Provider.Equals("Mailgun", StringComparison.InvariantCultureIgnoreCase))
            throw new InvalidDataException("Provider is not Mailgun");

        //Store the input request
        var storageHandler = StorageFactory.GetStorageHandler();
        storageHandler.Save($"Mailgun{DateTime.UtcNow:yyyy-MM-dd--hh-mm-ss}", bytes);

        //Publish the notification
        try
        {
            var notificationHandler = NotificationFactory.GetNotificationHandler();
            await notificationHandler.notify(inputString ?? "");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
