﻿using MailGunService.Notification.Handlers;
using MailGunService.Notification.Interfaces;

namespace MailGunService.Notification
{
    public static class NotificationFactory
    {
        public static INotificationHandler GetNotificationHandler()
        {
            var notificationProvider = Environment.GetEnvironmentVariable("NotificationServiceProvider");

            if (string.IsNullOrWhiteSpace(notificationProvider))
                throw new ArgumentNullException(nameof(notificationProvider));

            switch (notificationProvider)
            {
                case "SNS":
                    return new SimpleNotificationHandler();
                default:
                    return new EventHubNotificationHandler();
            }
        }
    }
}
