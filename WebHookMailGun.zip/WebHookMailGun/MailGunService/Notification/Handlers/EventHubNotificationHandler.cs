﻿using MailGunService.Notification.Interfaces;

namespace MailGunService.Notification.Handlers;

public class EventHubNotificationHandler : INotificationHandler
{
    public Task<bool> notify(string message)
    {
        throw new NotImplementedException();
    }
}