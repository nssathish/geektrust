﻿using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;
using MailGunService.Notification.Interfaces;

namespace MailGunService.Notification.Handlers
{
    public class SimpleNotificationHandler : INotificationHandler
    {
        public async Task<bool> notify(string message)
        {
            try
            {
                var config = new AmazonSimpleNotificationServiceConfig()
                {
                    RegionEndpoint = Amazon.RegionEndpoint.USEast1,
                    ServiceURL = "https://us-east-1.console.aws.amazon.com/"
                };

                var notificationService = new AmazonSimpleNotificationServiceClient(awsAccessKeyId: "accesskey", awsSecretAccessKey: "secret", config);
                var request = new PublishRequest
                {
                    Message = message,
                    TopicArn = "arn"

                };

                try
                {
                    var response = await notificationService.PublishAsync(request);

                    Console.WriteLine("Message sent to topic:");
                    Console.WriteLine(message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Caught exception publishing request:");
                    Console.WriteLine(ex.Message);
                }
                
                return true;

            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
