﻿using MailGunService.Notification.Interfaces;

namespace MailGunService.Notification.Handlers
{
    public class SimpleNotificationHandler : INotificationHandler
    {
        public bool notify(string message)
        {
            throw new NotImplementedException();
        }
    }
}
