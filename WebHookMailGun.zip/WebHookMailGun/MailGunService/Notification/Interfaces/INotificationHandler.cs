﻿namespace MailGunService.Notification.Interfaces
{
    public interface INotificationHandler
    {
        Task<bool> notify(string message);
    }
}
