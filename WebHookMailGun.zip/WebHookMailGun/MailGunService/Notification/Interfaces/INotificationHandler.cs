﻿namespace MailGunService.Notification.Interfaces
{
    public interface INotificationHandler
    {
        bool notify(string message);
    }
}
