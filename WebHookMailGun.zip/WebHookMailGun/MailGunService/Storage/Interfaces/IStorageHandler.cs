﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailGunService.Storage.Interfaces
{
    public interface IStorageHandler
    {
        byte[] Read(string name);
        bool Save(string name, byte[] content);
    }
}
