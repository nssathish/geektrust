﻿using MailGunService.Storage.Interfaces;

namespace MailGunService.Storage.Handlers
{
    public class S3StorageHandler : IStorageHandler
    {
        public byte[] Read(string name)
        {
            throw new NotImplementedException();
        }

        public bool Save(string name, byte[] content)
        {
            throw new NotImplementedException();
        }
    }
}
