﻿using MailGunService.Storage.Interfaces;

namespace MailGunService.Storage.Handlers
{
    public class DiskStorageHandler : IStorageHandler
    {
        public byte[] Read(string name)
        {
            throw new NotImplementedException();
        }

        public bool Save(string name, byte[] content)
        {
            try
            {
                using (var file = File.OpenWrite(name))
                {
                    file.Position = 0;
                    file.Write(content);
                    file.Close();
                }
                return true;

            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
