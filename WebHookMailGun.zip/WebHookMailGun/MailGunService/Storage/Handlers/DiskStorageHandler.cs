﻿using MailGunService.Storage.Interfaces;

namespace MailGunService.Storage.Handlers
{
    public class DiskStorageHandler : IStorageHandler
    {
        public byte[] Read(string name)
        {
            throw new NotImplementedException();
        }

        public bool Save(string name, byte[] content)
        {
            throw new NotImplementedException();
        }
    }
}
