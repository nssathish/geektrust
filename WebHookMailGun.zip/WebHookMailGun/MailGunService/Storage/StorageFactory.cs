﻿using MailGunService.Storage.Handlers;
using MailGunService.Storage.Interfaces;

namespace MailGunService.Storage
{
    public static class StorageFactory
    {
        public static IStorageHandler GetStorageHandler()
        {
            var storageProvider = Environment.GetEnvironmentVariable("StorageProvider");

            if (string.IsNullOrWhiteSpace(storageProvider))
                throw new ArgumentNullException(nameof(storageProvider));

            switch (storageProvider)
            {
                case "S3":
                    return new S3StorageHandler();
                default:
                    return new DiskStorageHandler();
            }
        }
    }
}
